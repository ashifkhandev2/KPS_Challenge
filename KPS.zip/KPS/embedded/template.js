

/*------ All Below variable we can adjust on css change ---------*/

var kps_ship = {
    distanceTraveledByShip: 0, // Distance covered by ship (default value 0)
    centreTopPosition: 190,    // Ship centre position as per LAKE & SHIP height,widht (As refrence use) (Note* Change the value as per Lake & height and width Properly for accurate result)
    centreLeftPosition: 180,   // Ship Left position as per LAKE & SHIP height,widht (As refrence use) (Note* Change the value as per Lake & height and width Properly for accurate result)
    topPosition: 190,          // Ship Initial top position on page load   (Note* Change the value as per Lake & height and width Properly for accurate result)
    leftPosition: 180,         // Ship Initial Left position on page load   (Note* Change the value as per Lake & height and width Properly for accurate result)
    shipWidth: 40,             // Ship width as per CSS
    shipHeight: 20,            // Ship Height as per CSS
    shipAtStationFlag: false,  // Ship at station or not flag
    shipAtMiddleStopped: true, // Ship stopped at middle lake or not flag
    shipRotateAngle: 0,        // Ship rotatation value  
    shipLastStation: '-',      // Ship Current station value 
    shipNextStation: '-',      // Ship Next station value
    shipSpeed: 10              // Ship moving speed adjustment in pixel (Default 10px)
};
var lake = {
    stOne: 'stOne',
    stTwo: 'stTwo',
    stThree: 'stThree',
    stFour: 'stFour',
    lakeHeight: 400,                  // Lake Height as per CSS
    lakeWidth: 400,                   // Lake Width as per CSS
    lakeStationThreeTopPosition: 10,  // Station three top position (Default 10px)
    lakeStationOneLeftPosition: 10,   // Station one left position (Default 10px)
    lakeStationTwoRightPosition: 10,  // Station two right position (Default 10px)
    lakeStationFourBottomPosition: 10 // Station four bottom position (Default 10px)
};
var intervalToCallMethod=100;
var clearIntervalFlag, boat, intervel;

/*---------------------------------------------------------------------------------------*/


/*===============================================
@Method: onload
@Description: To set ship default position and
 create button event listner
===============================================*/



window.onload = function(e) {
    boat = document.getElementById('boat');
    document.getElementsByClassName('navigate')[0].onclick = function() {
        driveShip(lake.stOne);
    };
    document.getElementsByClassName('navigate')[1].onclick = function() {
        driveShip(lake.stTwo);
    };
    document.getElementsByClassName('navigate')[2].onclick = function() {
        driveShip(lake.stThree);
    };
    document.getElementsByClassName('navigate')[3].onclick = function() {
        driveShip(lake.stFour);
    };
    setShipLocation();
};

/*===============================================
@Method: setShipLocation
@Description: To set all status of ship
===============================================*/

function setShipLocation() {
    boat.style = 'position: relative;top:' + kps_ship.topPosition + 'px;left:' + kps_ship.leftPosition + 'px;-ms-transform: rotate(' + kps_ship.shipRotateAngle + 'deg);-webkit-transform: rotate(' + kps_ship.shipRotateAngle + 'deg);transform: rotate(' + kps_ship.shipRotateAngle + 'deg)';
    document.getElementById('last-station').innerHTML = kps_ship.shipLastStation;
    document.getElementById('travel').innerHTML = kps_ship.distanceTraveledByShip + 'px';
    document.getElementById('moving').innerHTML = kps_ship.shipAtStationFlag || kps_ship.shipAtMiddleStopped ? 0 : 1;
    if (kps_ship.shipAtStationFlag) clearInterval(clearIntervalFlag);
}

/*===============================================
@Method: driveShip
@parameter:stationNumber (String : ' stationNumber ')
@Description: on click station button ship move from
 current station to centre position of lake then move
 ship to commanded station
===============================================*/

function driveShip(stationNumber) {

    kps_ship.shipAtStationFlag = false;
    kps_ship.shipAtMiddleStopped = false;
    if (intervel) clearInterval(intervel);
    if (clearIntervalFlag) clearInterval(clearIntervalFlag);

    if ((kps_ship.topPosition == kps_ship.centreTopPosition && kps_ship.leftPosition == kps_ship.centreLeftPosition) ||
        kps_ship.shipNextStation == stationNumber) {
        ShipDrivingToStation(stationNumber);
        return;
    } else if (kps_ship.topPosition > kps_ship.centreTopPosition && kps_ship.leftPosition == kps_ship.centreLeftPosition) {
        stationFourToCentreOfLake(stationNumber);
        return;
    } else if (kps_ship.topPosition < kps_ship.centreTopPosition && kps_ship.leftPosition == kps_ship.centreLeftPosition) {
        stationThreeToCentreOfLake(stationNumber);
        return;
    } else if (kps_ship.topPosition == kps_ship.centreTopPosition && kps_ship.leftPosition > kps_ship.centreLeftPosition) {
        stationTwoToCentreOfLake(stationNumber);
        return;
    } else if (kps_ship.topPosition == kps_ship.centreTopPosition && kps_ship.leftPosition < kps_ship.centreLeftPosition) {
        stationOneToCentreOfLake(stationNumber);
        return;
    }
}

/*===============================================
@Method: stationOneToCentreOfLake
@parameter:stationNumber (String : ' stationNumber ')
@Description: to move ship from station One To Centre
 Of Lake
===============================================*/

function stationOneToCentreOfLake(stationNumber) {
    intervel = setInterval(function() {
        if (kps_ship.leftPosition < kps_ship.centreLeftPosition - kps_ship.shipSpeed) {
            kps_ship.leftPosition += kps_ship.shipSpeed;
            kps_ship.distanceTraveledByShip += kps_ship.shipSpeed;
        } else {
            kps_ship.distanceTraveledByShip += kps_ship.centreLeftPosition - kps_ship.leftPosition;
            kps_ship.leftPosition = kps_ship.centreLeftPosition;
        }
        setShipLocation();
        if (kps_ship.leftPosition == kps_ship.centreLeftPosition) {
            clearInterval(intervel);
            ShipDrivingToStation(stationNumber);
        }
    }, intervalToCallMethod);
}


/*===============================================
@Method: stationTwoToCentreOfLake
@parameter:stationNumber (String : ' stationNumber ')
@Description: to move ship from station Two To Centre
 Of Lake
===============================================*/

function stationTwoToCentreOfLake(stationNumber) {
    intervel = setInterval(function() {
        if (kps_ship.leftPosition > kps_ship.centreLeftPosition + kps_ship.shipSpeed) {
            kps_ship.leftPosition -= kps_ship.shipSpeed;
            kps_ship.distanceTraveledByShip += kps_ship.shipSpeed;
        } else {
            kps_ship.distanceTraveledByShip += kps_ship.leftPosition - kps_ship.centreLeftPosition;
            kps_ship.leftPosition = kps_ship.centreLeftPosition;
        }
        setShipLocation();
        if (kps_ship.leftPosition == kps_ship.centreLeftPosition) {
            clearInterval(intervel);
            ShipDrivingToStation(stationNumber);
        }
    }, intervalToCallMethod);
}


/*===============================================
@Method: stationThreeToCentreOfLake
@parameter:stationNumber (String : ' stationNumber ')
@Description: to move ship from station Three To Centre
 Of Lake
===============================================*/


function stationThreeToCentreOfLake(stationNumber) {
    intervel = setInterval(function() {
        if (kps_ship.topPosition < kps_ship.centreTopPosition - kps_ship.shipSpeed) {
            kps_ship.topPosition += kps_ship.shipSpeed;
            kps_ship.distanceTraveledByShip += kps_ship.shipSpeed;
        } else {
            kps_ship.distanceTraveledByShip += kps_ship.centreTopPosition - kps_ship.topPosition;
            kps_ship.topPosition = kps_ship.centreTopPosition;
        }
        setShipLocation();
        if (kps_ship.topPosition == kps_ship.centreTopPosition) {
            clearInterval(intervel);
            ShipDrivingToStation(stationNumber);
        }
    }, intervalToCallMethod);
}

/*===============================================
@Method: stationFourToCentreOfLake
@parameter:stationNumber (String : ' stationNumber ')
@Description: to move ship from station Four To Centre
 Of Lake
===============================================*/

function stationFourToCentreOfLake(stationNumber) {
    intervel = setInterval(function() {
        if (kps_ship.topPosition > kps_ship.centreTopPosition + kps_ship.shipSpeed) {
            kps_ship.topPosition -= kps_ship.shipSpeed;
            kps_ship.distanceTraveledByShip += kps_ship.shipSpeed;
        } else {
            kps_ship.distanceTraveledByShip += kps_ship.topPosition - kps_ship.centreTopPosition;
            kps_ship.topPosition = kps_ship.centreTopPosition;
        }
        setShipLocation();
        if (kps_ship.topPosition == kps_ship.centreTopPosition) {
            clearInterval(intervel);
            ShipDrivingToStation(stationNumber);
        }
    }, intervalToCallMethod);
}



/*===============================================
@Method: ShipDrivingToStation
@parameter:stationNumber (String : ' stationNumber ')
@Description: To move ship from middle position 
to Station of lake Common method for all station
===============================================*/

function ShipDrivingToStation(stationNumber) {
    kps_ship.shipNextStation = stationNumber;
    if (clearIntervalFlag) clearInterval(clearIntervalFlag);
    clearIntervalFlag = setInterval(function() {
        ShipDrivingToStationLoaction(stationNumber);
    }, intervalToCallMethod);
}


/*===============================================
@Method: ShipDrivingToStationLoaction
@parameter:stationNumber (String : ' stationNumber ')
@Description: To move ship from middle position to 
Station of lake as per value of "stationNumber"
===============================================*/

function ShipDrivingToStationLoaction(stationNumber) {
    switch (stationNumber) {

        case lake.stOne:
            driveToStationOne(stationNumber);
            break;

        case lake.stTwo:
            driveToStationTwo(stationNumber);
            break;

        case lake.stThree:
            driveToStationThree(stationNumber);
            break;

        case lake.stFour:
            driveToStationFour(stationNumber);
            break;

        default:
            console.log('Stop');
    }

}


/*===============================================
@Method: driveToStationOne
@parameter:stationNumber (String : ' stationNumber ')
@Description: To move ship from middle position to 
station one
===============================================*/
function driveToStationOne(stationNumber) {
    kps_ship.shipRotateAngle = 0;
    if (kps_ship.leftPosition > lake.lakeStationOneLeftPosition + kps_ship.shipSpeed) {
        kps_ship.leftPosition -= kps_ship.shipSpeed;
        kps_ship.distanceTraveledByShip += kps_ship.shipSpeed;
    } else {
        kps_ship.distanceTraveledByShip += kps_ship.leftPosition - lake.lakeStationOneLeftPosition;
        kps_ship.leftPosition = lake.lakeStationOneLeftPosition;
        kps_ship.shipAtStationFlag = true;
        kps_ship.shipLastStation = '1';
    }
    setShipLocation();
}


/*===============================================
@Method: driveToStationTwo
@parameter:stationNumber (String : ' stationNumber ')
@Description: To move ship from middle position to 
station two
===============================================*/
function driveToStationTwo(stationNumber) {
    kps_ship.shipRotateAngle = 0;
    if (kps_ship.leftPosition < lake.lakeWidth - lake.lakeStationTwoRightPosition - kps_ship.shipWidth - kps_ship.shipSpeed) {
        kps_ship.leftPosition += kps_ship.shipSpeed;
        kps_ship.distanceTraveledByShip += kps_ship.shipSpeed;
    } else {
        kps_ship.distanceTraveledByShip += lake.lakeWidth - lake.lakeStationTwoRightPosition - kps_ship.shipWidth - kps_ship.leftPosition;
        kps_ship.leftPosition = lake.lakeWidth - lake.lakeStationTwoRightPosition - kps_ship.shipWidth;
        kps_ship.shipAtStationFlag = true;
        kps_ship.shipLastStation = '2';
    }
    setShipLocation();
}


/*===============================================
@Method: driveToStationThree
@parameter:stationNumber (String : ' stationNumber ')
@Description: To move ship from middle position to 
station three
===============================================*/
function driveToStationThree(stationNumber) {
    kps_ship.shipRotateAngle = 90;
    if (kps_ship.topPosition >(lake.lakeStationThreeTopPosition+rotationAdjustment()) + kps_ship.shipSpeed) {
        kps_ship.topPosition -= kps_ship.shipSpeed;
        kps_ship.distanceTraveledByShip += kps_ship.shipSpeed;
    } else {
        kps_ship.distanceTraveledByShip += kps_ship.topPosition -(lake.lakeStationThreeTopPosition+rotationAdjustment());
        kps_ship.topPosition = lake.lakeStationThreeTopPosition+rotationAdjustment();
        kps_ship.shipAtStationFlag = true;
        kps_ship.shipLastStation = '3';
    }
    setShipLocation();
}


/*===============================================
@Method: driveToStationFour
@parameter:stationNumber (String : ' stationNumber ')
@Description: To move ship from middle position to 
station four
===============================================*/
function driveToStationFour() {
    kps_ship.shipRotateAngle = 90;
    if (kps_ship.topPosition < lake.lakeHeight -lake.lakeStationFourBottomPosition-kps_ship.shipWidth+rotationAdjustment() - kps_ship.shipSpeed) {
        kps_ship.topPosition += kps_ship.shipSpeed;
        kps_ship.distanceTraveledByShip += kps_ship.shipSpeed;
    } else {
        kps_ship.distanceTraveledByShip += lake.lakeHeight -lake.lakeStationFourBottomPosition-kps_ship.shipWidth+rotationAdjustment() - kps_ship.topPosition;
        kps_ship.topPosition = lake.lakeHeight -lake.lakeStationFourBottomPosition-kps_ship.shipWidth+rotationAdjustment();
        kps_ship.shipAtStationFlag = true;
        kps_ship.shipLastStation = '4';
    }
    setShipLocation();
}


/*===============================================
@Method: rotationAdjustment
@Description: to adjust ship movement on ship rotate(turn) at centre of lake
===============================================*/
function rotationAdjustment(){
    return (kps_ship.shipWidth-kps_ship.shipHeight)/2;
}





